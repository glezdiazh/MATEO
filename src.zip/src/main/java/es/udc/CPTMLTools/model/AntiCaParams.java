package es.udc.CPTMLTools.model;

public class AntiCaParams {
	
	private byte[] file;	
	private String content;
	
	
	public byte[] getFile() {
		return file;
	}
	
	public void setFile(byte[] file) {
		this.file = file;
	}
	
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}

}



